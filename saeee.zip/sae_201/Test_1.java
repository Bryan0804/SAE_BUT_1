package sae_201;
import ardoise.*;

public class Test_1 {
		public static void main(String []args ){

		Ardoise ardoise = new Ardoise();

		ardoise.test();

		}
}
